// Add your JavaScript code here

document.getElementById('customize-btn').addEventListener('click', function() {
    // Retrieve selected options
    var color = document.getElementById('color').value;
    var size = document.getElementById('size').value;
    var interior = document.querySelector('input[name="interior"]:checked').value;
    var seats = document.getElementById('seats').value;
    var motorPower = document.getElementById('motor-power').value;
    var solarPanels = document.getElementById('solar-panels').value;
    var batteryType = document.getElementById('battery-type').value;
    var autodrive = document.getElementById('autodrive').checked;
  
    // Display selected options in results section
    var resultsSection = document.getElementById('results-section');
    resultsSection.innerHTML = '<h2>Selected Options:</h2>';
    resultsSection.innerHTML += '<p><strong>Color:</strong> ' + color + '</p>';
    resultsSection.innerHTML += '<p><strong>Size:</strong> ' + size + '</p>';
    resultsSection.innerHTML += '<p><strong>Interior:</strong> ' + interior + '</p>';
    resultsSection.innerHTML += '<p><strong>Seats:</strong> ' + seats + '</p>';
    resultsSection.innerHTML += '<p><strong>Motor Power:</strong> ' + motorPower + '</p>';
    resultsSection.innerHTML += '<p><strong>Solar Panels:</strong> ' + solarPanels + '</p>';
    resultsSection.innerHTML += '<p><strong>Battery Type:</strong> ' + batteryType + '</p>';
    resultsSection.innerHTML += '<p><strong>Autodrive Mode:</strong> ' + (autodrive ? 'Enabled' : 'Disabled') + '</p>';
  });

  
  