const header = document.querySelector("header");

window.addEventListener("scroll", function () {
    header.classList.toggle("sticky", window.scrollY > 0);
});
document.getElementById('investor-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const company = document.getElementById('company').value;
    const investmentAmount = document.getElementById('investment-amount').value;
    const message = document.getElementById('message').value;

    alert('Thank you for your investment!');
    document.getElementById('name').value = '';
    document.getElementById('email').value = '';
    document.getElementById('phone').value = '';
    document.getElementById('company').value = '';
    document.getElementById('investment-amount').value = '';
    document.getElementById('message').value = '';
});
