const header = document.querySelector("header");
const wrapper = document.getElementsByClassName("wrapper")[0];
const emailForm = document.getElementById('emailForm');
const emailInput = document.getElementById('emailInput');
const modal = document.getElementById('myModal');
const closeModal = document.getElementsByClassName('close')[0];
const message = document.getElementById('message');

wrapper.addEventListener("scroll", function () {
    if (wrapper.scrollTop > 0)
        header.classList.add("sticky");
    else
        header.classList.remove("sticky")
});

document.addEventListener("DOMContentLoaded", function () {
    var detailsButtons = document.querySelectorAll(".btn-details");
    var buyButtons = document.querySelectorAll(".btn-buy");

    detailsButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            var productInfo = this.closest(".product-item").querySelector(".product-info");
            console.log("Details button clicked:", productInfo);
        });
    });
    buyButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            var productInfo = this.closest(".product-item").querySelector(".product-info");
            console.log("Buy button clicked:", productInfo);
        });
    });
});





emailForm.addEventListener('submit', function (event) {
    event.preventDefault();
    const email = emailInput.value;
    message.textContent = `Thank you! Your email (${email}) has been send.`;
    modal.style.display = 'block';
});
closeModal.addEventListener('click', function () {
    modal.style.display = 'none';
});

function scrollToSection(id) {
    let element = document.getElementById(id);

    element.scrollIntoView({
        behavior: 'smooth',
        block: "start" // or start, center, end, nearest
    })
}


